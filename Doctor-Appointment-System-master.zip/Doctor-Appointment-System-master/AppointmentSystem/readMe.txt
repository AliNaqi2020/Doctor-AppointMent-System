URL : http://localhost/AppointmentSystem/Login.php

User's list:

Patient - ksavakia@uncc.edu,password: khyati
Receptionist - nmodi@uncc.edu, password: narendra
doctor - jbond@uncc.edu, password: james